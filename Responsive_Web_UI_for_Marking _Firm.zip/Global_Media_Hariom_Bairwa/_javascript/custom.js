/**
 * Created by Hariom Bairwa on 26-Dec-17.
 */


jQuery(document).ready(function() {

    /* START -- Dynamic Color change for the Services section */
    $("div#adv_pub_agen div.col-sm-4 div").mouseenter(
        function () {
            $(this).css("background-color","#F49F32");
            $(this).find("h4").css("color","#f9f9f9");
            $(this).find("p").css("color","#f9f9f9");
            $(this).find("span a").css("color","#f9f9f9");
            $(this).find("span button").css("background-color","#f9f9f9");
            $(this).find("button a").css("color","#403114")
        }
    ).mouseleave(function () {
        $(this).css("background-color","#f9f9f9");
        $("div#adv_pub_agen div div h4, div#adv_pub_agen p,div#adv_pub_agen div div span a").css("color","#403114");
        $("div#adv_pub_agen span button").css("background-color","#F49F32");
        $("div#adv_pub_agen div div button a").css("color","#f9f9f9")
    });
    /* END -- Dynamic Color change for the Services section */

    /* START -- Dynamic Color change for How we are working section */
    $("section#how_we_work  div.row div.col-sm-2 div").mouseenter(
        function () {
            $(this).css("background-color","#F49F32");
            $(this).find("p").css("color","#f9f9f9");
        }
    ).mouseleave(function () {
        $(this).css("background-color","#ffffff");
        $("section#how_we_work  div.row div.col-sm-2 div p").css("color","#403114")
    });
    /* END -- Dynamic Color change for How we are working section */

});